<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'planni8_wp325');

/** MySQL database username */
define('DB_USER', 'planni8_wp325');

/** MySQL database password */
define('DB_PASSWORD', 'p]346ISt.O');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('DISALLOW_FILE_EDIT', TRUE); // Sucuri Security: Sun, 19 Mar 2017 03:49:39 +0000


/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '0gkj6xkcjqwwrm8latudc4bqpgvbgucfpxnnt2xcaicvs20yyo39jdeh9vpsjp8r');
define('SECURE_AUTH_KEY',  'wjio929ess7ktunbzcyh1y5qt3fpxlhwgqpdlrclsvfbjxw57ku4gevl8g1yexfj');
define('LOGGED_IN_KEY',    '9jdko8eepaclyeufidvylnlnq7th7guuuckczbanhccvl2qvphhbfsvwrarmaabm');
define('NONCE_KEY',        'lfknkbncabbt98elyahnkis0jqonpg4usospndvhwifebk9ozpr4zysol8f3iplx');
define('AUTH_SALT',        'lyi2xxmy0yo8gegu2wafkfkamstxbacdilnj6hx9crbfhlgsytqwucd3jddrflsn');
define('SECURE_AUTH_SALT', 'iwsapi5kdpweozsoarp8j8ne0kkyrakb63ntw3ddcq1jaibn6gsm2uyo6oisxizf');
define('LOGGED_IN_SALT',   'hz8ivknuohluhk5fs78cdoyxxauptcmoebx2n6ihhhjolubqvz4skgqxm7c3wmkn');
define('NONCE_SALT',       '6b5hjlzpzmcpqgmd4rqzioohc0iez1iqmq9wj8ootgo3xu8mjnezuz4hn7dsgmuw');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wpzl_nHjRSEdqa';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
