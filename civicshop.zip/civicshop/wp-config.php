<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'planni8_wp671');

/** MySQL database username */
define('DB_USER', 'planni8_wp671');

/** MySQL database password */
define('DB_PASSWORD', '(@SB98pv9s');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

define('DISALLOW_FILE_EDIT', TRUE); // Sucuri Security: Sat, 25 Mar 2017 05:37:45 +0000


/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'ri89sk38khlkjuqnulmykwc4qmdgntsn6vnvpqvxguwe7errwdy4dfvakrgdkews');
define('SECURE_AUTH_KEY',  'cow4vdzn9bcl7s4bwkucih0xjfbovxwdwww8gs4fo8lx5yjxzv2qyxflvijfhtpd');
define('LOGGED_IN_KEY',    '1neiwm3ockqkx0qpzrssvdpelqbkpnpyp5pvieqkgtqfzp2nfvzpjg1z1fhf6gjk');
define('NONCE_KEY',        'a1sydgghthyflfs37jf5rdognk8bkw0cdooc6l4hgciycujuulyapakpobqr8i8s');
define('AUTH_SALT',        'mxvtdklbdjhxupq1o3tcgpiibwrzrkflntylidfl8snxegshqoeekfd12ofxohda');
define('SECURE_AUTH_SALT', 'bi7ejrv2tbj3cebnkwmuzcvboqec743gxsvropxsqv50nbo7yf5q1g110dgdaker');
define('LOGGED_IN_SALT',   'pon8yfkxvqtsuftjffp06xek9tgpqmsxvrjhcoqzvmlehjte6bganwvaphwfd14l');
define('NONCE_SALT',       'trkfcx2c3qhxotdve1zaucgidiukfminieuwcwek1224jo0mmehnlwvxm3to3mw7');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp5o_rt45xWgPe';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
